#include "planes.h"



using namespace cm::data;

Planes::Planes(QObject *parent) : QObject(parent)
{

}

Planes::~Planes()
{

}
